﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QueryableEnumerableApp.Model
{
    class Student
    {
        public Student()
        {
            this.Id = Guid.NewGuid().ToString();
        }

        public string Id { get; set; }
        public string FullName { get; set; }
        public double Cgpa { get; set; }
    }
}
