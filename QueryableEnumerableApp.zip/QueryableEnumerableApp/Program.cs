﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using QueryableEnumerableApp.Model;

namespace QueryableEnumerableApp
{
    class Program
    {
        static void Main(string[] args)
        {
            StudentDBContext db = new StudentDBContext();
            //Student s1 = new Student { FullName = "Sachin Tendulkar", Cgpa = 9.2};
            //Student s2 = new Student { FullName = "Siddhesh Yellaram", Cgpa = 9.4 };
            //Student s3 = new Student { FullName = "Simran Shah", Cgpa = 8.8 };
            //Student s4 = new Student { FullName = "Sam Curran", Cgpa = 8.7 };
            //Student s5 = new Student { FullName = "Bam Zahard", Cgpa = 8.8 };
            //db.Students.Add(s1);
            //db.Students.Add(s2);
            //db.Students.Add(s3);
            //db.Students.Add(s4);
            //db.Students.Add(s5);
            //db.SaveChanges();
            //StudentsWithFullName(db);
            StudentsWithFirstNameList(db);
        }

        static void StudentsWithFullName(StudentDBContext d)
        {
            var FullNameStartsWithS = d.Students.Where(s => s.FullName.StartsWith("S")).Select(s => new
            {
                s.FullName,
                s.Cgpa
            });

            Console.WriteLine("Sql Expression Built");
            Console.WriteLine(FullNameStartsWithS);

            var FullNameStartsWithSList = FullNameStartsWithS.ToList();

            foreach(var s in FullNameStartsWithSList)
            {
                Console.WriteLine(s.FullName);
                Console.WriteLine(s.Cgpa);
            }
        }

        static void StudentsWithFirstNameErr(StudentDBContext d)
        {
            var FirstNameStartsWithS = d.Students.Where(s => s.FullName.StartsWith("S")).Select(s => new
            {
                FirstName = s.FullName.Split(' ')[0],
                CGPA = s.Cgpa
            });

            Console.WriteLine("Sql Expression Built");
            Console.WriteLine(FirstNameStartsWithS);

            var FirstNameStartsWithSList = FirstNameStartsWithS.ToList();

            foreach (var s in FirstNameStartsWithSList)
            {
                Console.WriteLine(s.FirstName);
                Console.WriteLine(s.CGPA);
            }
        }

        static void StudentsWithFirstName(StudentDBContext d)
        {
            var FirstNameStartsWithS = d.Students.Where(s => s.FullName.StartsWith("S")).AsEnumerable().Select(s => new
            {
                FirstName = s.FullName.Split(' ')[0],
                CGPA = s.Cgpa
            });

            Console.WriteLine("Sql Expression Built");
            Console.WriteLine(FirstNameStartsWithS);

            var FirstNameStartsWithSList = FirstNameStartsWithS.ToList();

            foreach (var s in FirstNameStartsWithSList)
            {
                Console.WriteLine(s.FirstName);
                Console.WriteLine(s.CGPA);
            }
        }

        static void StudentsWithFirstNameList(StudentDBContext d)
        {
            var FirstNameStartsWithS = d.Students.Where(s => s.FullName.StartsWith("S")).ToList().Select(s => new
            {
                FirstName = s.FullName.Split(' ')[0],
                CGPA = s.Cgpa
            });

            Console.WriteLine("Sql Expression Built");
            Console.WriteLine(FirstNameStartsWithS);

            var FirstNameStartsWithSList = FirstNameStartsWithS.ToList();
            Console.WriteLine(FirstNameStartsWithSList);

            //foreach (var s in FirstNameStartsWithSList)
            //{
            //    Console.WriteLine(s.FirstName);
            //    Console.WriteLine(s.CGPA);
            //}
        }
    }
}
